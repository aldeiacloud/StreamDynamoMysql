
const { SendMessageCommand, SQSClient } = require("@aws-sdk/client-sqs");

const sqs = new SQSClient({});
const queueUrl = process.env.SQS_QUEUE_URL; // VARIÁVEL DE AMBIENTE COM SQS FIFO - SOMENTE FIFO FUNCIONA NESSE CÓDIGO

exports.handler = async (event) => {
  for (const record of event.Records) {
    if (['INSERT', 'MODIFY', 'REMOVE'].includes(record.eventName)) {
      try {
        const item = record.dynamodb.NewImage ?? record.dynamodb.OldImage
        const message = {
          eventName: record.eventName,
          dynamodb: record.dynamodb
        };

        // Usando usection_id, section_id e question como parte do MessageGroupId
        const usection_id = item.usection_id.N;
        const section_id = item.section_id.N;
        const question = item.question.N;
        const messageGroupId = `usection-${usection_id}-section-${section_id}-question-${question}`;
      
        
        const command = new SendMessageCommand({
          QueueUrl: queueUrl,
          MessageBody: JSON.stringify(message),
          MessageGroupId: messageGroupId
        });
          
        await sqs.send(command);

        console.info(`Message sent to SQS: ${JSON.stringify(message)}`);
      } catch (error) {
        console.error(`Error sending message to SQS: ${error.message}`, { error });
      }
    }
  }

  console.info('Lambda execution completed');
};
