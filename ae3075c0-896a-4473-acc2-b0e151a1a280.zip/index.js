const { SQSClient, SendMessageCommand, ReceiveMessageCommand, DeleteMessageCommand } = require("@aws-sdk/client-sqs");
const mysql = require('mysql');
const { promisify } = require('util')

// Configuração personalizada para aumentar o timeout nas tentativas de conexão
// Configuração do cliente DLQ com o endpoint HTTP
const dlqEndpointUrl = process.env.DLQ_ENDPOINT_URL;

const sqs = new SQSClient({
    maxRetries: 10,
    httpOptions: {
        timeout: 120000
    }
});

// Carrega as credenciais do RDS a partir das variáveis de ambiente
const dbConfig = {
    user: process.env.RDS_USERNAME,
    password: process.env.RDS_PASSWORD,
    host: process.env.RDS_HOST,
    database: process.env.RDS_DATABASE,
    port: process.env.RDS_PORT
};

// Função para conectar ao banco de dados MySQL com tentativas de retry
async function connectToMySQL(retryAttempts = 5, delay = 120000) {
    for (let attempt = 0; attempt < retryAttempts; attempt++) {
        try {
            const connection = mysql.createConnection(dbConfig);
            await promisify(connection.connect).call(connection);
            return connection;
        } catch (err) {
            console.error("Error connecting to MySQL", { error: err.message });
            if (attempt < retryAttempts - 1) {
                console.info(`Retrying in ${delay / 1000} seconds...`);
                await new Promise(res => setTimeout(res, delay));
            } else {
                throw err;
            }
        }
    }
}

// Função para processar um registro do SQS
async function processRecord(record) {
    let connection;
    try {
        console.info("Processing SQS message:", record);

        const messageBody = JSON.parse(record.body);
        console.info(`Parsed message body: ${record.body}`);

        const eventName = messageBody.eventName;
        const dynamodb = messageBody.dynamodb;

        const keys = dynamodb.Keys;
        const newImage = dynamodb?.NewImage || {};

        const usectionId = keys.usection_id.N;
        const question = keys.question.N;
        const sectionId = newImage?.section_id ? newImage?.section_id?.N : "";

        connection = await connectToMySQL();
        const query = promisify(connection.query).bind(connection);

        let sqlScript, sqlValue;

        // Realiza a operação correspondente com base no evento
        if (eventName === "INSERT") {
            sqlScript = "INSERT INTO account_answers (usection_id, question, section_id) VALUES (?, ?, ?)";
            sqlValue = [usectionId, question, sectionId];
            await query(sqlScript, sqlValue);
            console.info("Record inserted successfully into account_answers table", { sqlValue });

        } else if (eventName === "MODIFY") {
            sqlScript = "UPDATE account_answers SET section_id = ? WHERE usection_id = ? AND question = ?";
            sqlValue = [sectionId, usectionId, question];
            await query(sqlScript, sqlValue);
            console.info("Record modified successfully in account_answers table", { sqlValue });

        } else if (eventName === "REMOVE") {
            sqlScript = "DELETE FROM account_answers WHERE usection_id = ? AND question = ?";
            sqlValue = [usectionId, question];
            await query(sqlScript, sqlValue);
            console.info("Record removed successfully from account_answers table", { sqlValue });
        }

    } catch (err) {
        console.error("Error processing SQS message", JSON.stringify(err));
        throw new Error(err ?? "Unknow error processing SQS message");
    } finally {
        if (connection) {
            connection.end();
        }
    }
}

// Função para reprocessar mensagens da DLQ com timeout e intervalo entre tentativas
async function reprocessDlqMessages(timeoutSeconds = 300, retryIntervalSeconds = 1) {
    try {
        console.info("Starting reprocessing of DLQ messages");

        const startTime = Date.now();

        while (true) {
            // Verifica se o tempo máximo de execução foi atingido
            if ((Date.now() - startTime) > (timeoutSeconds * 1000)) {
                console.info("Timeout reached for DLQ reprocessing");
                break;
            }

            try {
                const command = new ReceiveMessageCommand({
                    QueueUrl: dlqEndpointUrl,
                    MaxNumberOfMessages: 10,
                    WaitTimeSeconds: 10
                });

                const response = await sqs.send(command)

                const messages = response.Messages || [];
                if (messages.length === 0) {
                    console.info("No more messages in DLQ");
                    break;
                }

                for (const message of messages) {
                    try {
                        await processWithRetry(message)
                        console.log('deu certo o retry dlq')
                        const command = new DeleteMessageCommand({
                            QueueUrl: dlqEndpointUrl,
                            ReceiptHandle: message.ReceiptHandle
                        });
                        await sqs.send(command);
                    } catch (err) {
                        console.error("Failed to reprocess message from DLQ", { message, error: err.message });
                    }
                }

                // Aguarda antes de tentar a próxima iteração para evitar sobrecarga no endpoint
                await new Promise(res => setTimeout(res, retryIntervalSeconds * 1000));

            } catch (err) {
                console.error("Error receiving messages from DLQ", { error: err.message });
                await new Promise(res => setTimeout(res, retryIntervalSeconds * 1000));  // Espera antes de tentar novamente em caso de falha
            }
        }

        console.info("Reprocessing of DLQ messages completed");

    } catch (err) {
        console.error("Error reprocessing DLQ messages", { error: err.message });
        throw err;
    }
}

// Função para processar um registro com tentativas de retry
async function processWithRetry(record, retries = 3, backoffInSeconds = 2) {
    let attempt = 0;
    while (attempt < retries) {
        try {
            await processRecord(record);
            console.log('sucesso')
            return;
        } catch (err) {
            attempt++;
            console.error(`Attempt ${attempt} failed: ${JSON.stringify(err)}`);
            if (attempt < retries) {
                await new Promise(res => setTimeout(res, backoffInSeconds * 1000 * (2 ** (attempt - 1))));  // Exponential backoff
            }else {
                throw err;
            }
        }
    }
}

// Função Lambda Handler
exports.handler = async (event, context) => {
    console.info("Starting the lambda_handler function for SQS to RDS");

    try {
        for (const record of event.Records) {
            try {
                await processWithRetry(record);
            } catch (err) {
                // Envia mensagem para DLQ para reprocessamento posterior
                console.error("Failed to process record after retries, sending to DLQ");
                try {
                    const command = new SendMessageCommand({
                        QueueUrl: dlqEndpointUrl,
                        MessageBody: JSON.stringify(record)
                    });

                    await sqs.send(command)
                } catch (err) {
                    console.error("Failed to send message to DLQ", { error: err.message });
                }
            }
        }

        // Reprocessa mensagens da DLQ se houver
        await reprocessDlqMessages();

    } catch (err) {
        console.error("Error processing records from SQS", { error: err.message });
    }

    console.info("lambda_handler function execution completed for SQS to RDS");
};